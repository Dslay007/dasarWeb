<html>
  <head>
    <title>Cara 01</title>
  </head>
  <body>
    <p>
      Tanggal Hari ini :
      <?php echo date("d M Y")?>
    </p>
  </body>
</html>
