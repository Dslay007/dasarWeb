<?php
echo '<html>';
echo '<head><title>Cara 02</title></head>';
echo '<body>'; // Tambahkan titik koma di sini
echo '<p>Tanggal Hari ini : '. date('d M Y').'</p>';
echo '</body>';
echo '</html>';
?>
